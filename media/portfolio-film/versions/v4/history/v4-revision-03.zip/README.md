# V4 — Encore un détail

Révision 3. Film de 45 secondes, 1920 × 1080, 60 images/s, stéréo 48 kHz.

Le curseur souris noir à contour blanc remplace le point vert et sa traînée. Il suit les ajustements, la préparation Python, la transmission aux serveurs et la vérification des connexions. Les petits témoins de serveurs et les paquets de données restent des éléments de la représentation du réseau.

L’écran « Ça marche », à 31,5–34,5 secondes, a été supprimé. Quatre fragments du logo se réunissent à sa place ; le curseur amène le dernier fragment et termine l’assemblage. Cette transition n’ajoute aucun slogan.

La bande-son entière est une nouvelle composition à 112 BPM : cordes pincées synthétisées, accords chaleureux, basse syncopée et percussions sèches. Aucun instrument, fichier sonore ou segment de la musique précédente n’est réutilisé. L’arrangement évolue sur 21 mesures et 45 secondes. Les changements d’images et les gestes utilisent 76 repères de bruitage. À 43,5 secondes, le clic mécanique de souris coïncide avec l’appui final ; la musique s’atténue brièvement pour le laisser ressortir.

Les quatre premières secondes et les images des 10,5 dernières secondes proviennent toujours du master V3, avec le nom complet, le cadrage et les animations d’origine. Seul leur accompagnement sonore change. La V3, la V4bis et le site restent inchangés.

## Fichiers

- `exports/michel-djoumessi-v4.mp4` : film avec le mixage final.
- `exports/bande-son-originale.wav` : mixage complet.
- `exports/musique-originale.wav` : musique seule.
- `exports/bruitages.wav` : bruitages seuls, sur la durée du film.
- `exports/clic-final.wav` : clic isolé, sans silence préalable.
- `exports/storyboard.jpg` : planche des séquences.
- `exports/motion-cues.json` et `exports/sync-events.json` : repères communs au son et à l’image.
- `exports/verification-technique.json` et `review/verification.md` : contrôles.
- `history/v4-initiale.zip` et `history/v4-revision-02.zip` : sauvegardes des deux révisions précédentes, avec sources et exports.

## Reproduction

Depuis ce dossier, avec Node.js, FFmpeg, Python et NumPy :

```powershell
$env:MEDIA_NODE_MODULES='C:/Users/djoum/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
pnpm preview
python source/score.py
pnpm render
python source/verify-film.py
```

Les polices, la texture et les logos proviennent des ressources du portfolio. La V3 archivée fournit uniquement les images d’ouverture et de final. Aucun média sonore issu des références externes n’est incorporé.
