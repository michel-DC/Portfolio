from __future__ import annotations

import importlib.util
import json
import math
import sys
import wave
from pathlib import Path

import numpy as np
from numpy.typing import NDArray


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "exports"
RATE = 48_000
DURATION = 45
BPM = 112
BEAT = 60 / BPM
FINAL_CLICK = 43.5
FloatArray = NDArray[np.float64]
sys.dont_write_bytecode = True


def instruments():
    specification = importlib.util.spec_from_file_location("sound_palette", ROOT / "source" / "sound-palette.py")
    if specification is None or specification.loader is None:
        raise RuntimeError("Palette sonore introuvable")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def add(track: FloatArray, signal: FloatArray, start: float, gain: float, pan: float = 0) -> None:
    offset = round(start * RATE)
    if offset < 0 or offset >= len(track):
        return
    length = min(len(signal), len(track) - offset)
    angle = (pan + 1) * math.pi / 4
    track[offset:offset + length, 0] += signal[:length] * gain * math.cos(angle)
    track[offset:offset + length, 1] += signal[:length] * gain * math.sin(angle)


def ambience(track: FloatArray, delays: list[tuple[float, float]]) -> FloatArray:
    result = track.copy()
    for delay, gain in delays:
        offset = round(delay * RATE)
        result[offset:] += track[:-offset, ::-1] * gain
    return result


def write_wav(filename: Path, samples: FloatArray) -> None:
    pcm = np.rint(np.clip(samples, -0.999, 0.999) * 32767).astype("<i2")
    with wave.open(str(filename), "wb") as output:
        output.setnchannels(2)
        output.setsampwidth(2)
        output.setframerate(RATE)
        output.writeframes(pcm.tobytes())


def harmony_and_theme(tones, count: int) -> FloatArray:
    harmony = np.zeros((count, 2))
    strings = np.zeros_like(harmony)
    chords = [[53, 60, 64, 69, 72], [57, 60, 64, 67, 71], [48, 55, 59, 62, 67], [55, 62, 65, 69, 74]]
    progression = [0, 1, 2, 3, 0, 1, 2, 3, 1, 0, 2, 3, 0, 1, 3, 2, 0, 3, 1, 0, 2]
    phrases = [
        [(0.5, 76, 1.3), (2, 72, 1.7), (3.25, 74, 1)],
        [(0, 71, 1.7), (1.75, 69, 1.3), (3, 67, 1.2)],
        [(0.75, 67, 1.2), (2, 71, 1.5), (3.5, 74, 1)],
        [(0.25, 74, 1.5), (2, 72, 1.8)],
        [(0, 76, 2.5), (2.75, 79, 1.5)],
        [(0.5, 76, 1.4), (2.5, 71, 1.3), (3.5, 72, 1)],
        [(0.25, 74, 1.4), (1.75, 72, 2)],
        [(0.5, 71, 1.5), (2.5, 67, 2)],
    ]
    for bar, chord_index in enumerate(progression):
        start = bar * 4 * BEAT
        chord = chords[chord_index]
        intensity = 0.8 if bar < 2 else 1 if bar < 13 else 0.85 if bar < 16 else 1.15
        for index, note in enumerate(chord):
            add(harmony, tones.velvet(note, 3.5), start, 0.095 * intensity, -0.5 + index * 0.25)
            add(strings, tones.guitar(note + 12, 2.8), start + 0.011 * index, 0.105 * intensity, -0.6 + index * 0.3)
        if bar > 1 and bar not in (14, 15, 20):
            for index, note in enumerate(chord[1:]):
                add(strings, tones.guitar(note + 12, 1.3), start + 2.75 * BEAT + index * 0.009, 0.055, 0.4 - index * 0.25)
        for offset, note, duration in phrases[bar % len(phrases)]:
            if bar < 2 or 4 <= bar < 8 or 10 <= bar < 14 or 16 <= bar < 20:
                add(strings, tones.guitar(note, duration), start + offset * BEAT, 0.23, math.sin(bar * 0.8) * 0.2)
    add(harmony, tones.velvet(72, 3.5), 41.5, 0.13, 0.2)
    return ambience(harmony, [(0.071, 0.19), (0.143, 0.13), (0.277, 0.08)]) + ambience(strings, [(BEAT * 0.75, 0.23), (BEAT * 1.5, 0.09)])


def groove(tones, count: int) -> FloatArray:
    track = np.zeros((count, 2))
    kick = tones.kick()
    snare = tones.snare()
    wood = tones.wood()
    roots = [29, 33, 24, 31, 29, 33, 24, 31, 33, 29, 24, 31, 29, 33, 31, 24, 29, 31, 33, 29, 24]
    for bar, root in enumerate(roots):
        start = bar * 4 * BEAT
        sparse = bar in (0, 14, 15, 20)
        intensity = 0.65 if sparse else 0.85 if bar < 4 else 1
        for offset in ([0, 2.5] if sparse else [0, 1.75, 2.5, 3.5] if bar % 2 else [0, 1.5, 2.75]):
            add(track, kick, start + offset * BEAT, 0.51 * intensity)
        for offset in ([3] if sparse else [1, 3]):
            add(track, snare, start + offset * BEAT + 0.007, 0.33 * intensity, -0.08)
        for step in range(8):
            if sparse and step % 2:
                continue
            swing = 0.023 if step % 2 else 0
            add(track, tones.shaker(0.13 if step == 7 else 0.065), start + step * BEAT / 2 + swing, (0.09 if step % 2 else 0.065) * intensity, -0.4 if step % 2 else 0.45)
        for offset, note, length, gain in [(0, root, 0.44, 0.26), (1.5, root + 12, 0.2, 0.14), (2.5, root, 0.4, 0.23), (3.25, root + (7 if bar % 2 else 12), 0.23, 0.15)]:
            add(track, tones.bass(note, length), start + offset * BEAT, gain * intensity)
        if bar % 2 and not sparse:
            add(track, wood, start + 2.25 * BEAT, 0.08, 0.55)
            add(track, wood, start + 3.75 * BEAT, 0.055, -0.55)
        if bar in (3, 7, 11, 16):
            for step in range(3):
                add(track, snare, start + (3.5 + step * 0.167) * BEAT, 0.075 + step * 0.025, step * 0.25 - 0.25)
    return track


def sound_design(tones, cues: dict, count: int) -> tuple[FloatArray, list[dict]]:
    effects = np.zeros((count, 2))
    sync = []
    mouse = tones.mouse_click()
    for index, event in enumerate(cues["cues"]):
        position = event["frame"] / 60
        sync.append({**event, "audioTime": position, "audioSample": event["frame"] * 800})
        kind = event["kind"]
        pan = math.sin(index * 0.6) * 0.28
        if kind == "click":
            add(effects, mouse, position, 0.64 if position == FINAL_CLICK else 0.23, 0)
        elif kind == "sweep":
            add(effects, tones.air(), max(0, position - 0.22), 0.18, pan)
        elif kind in ("hit", "cut"):
            add(effects, tones.kick(), position, 0.22)
            add(effects, tones.wood(), position, 0.07, pan)
        elif kind in ("tick", "letter", "logo"):
            add(effects, tones.wood(), position, 0.065 if kind != "letter" else 0.028, pan)
        elif kind == "tone":
            add(effects, tones.guitar([72, 76, 79][index % 3], 1), position, 0.1, pan)
    write_wav(OUTPUT / "clic-final.wav", np.column_stack([mouse, mouse]) * 0.64 / math.sqrt(2))
    return effects, sync


def compose() -> None:
    tones = instruments()
    count = DURATION * RATE
    times = np.arange(count) / RATE
    cues = json.loads((OUTPUT / "motion-cues.json").read_text(encoding="utf-8"))
    music = np.tanh((harmony_and_theme(tones, count) + groove(tones, count)) * 1.15)
    music *= 0.79 / max(float(np.max(np.abs(music))), 1e-9)
    fade = np.minimum(times / 0.025, 1) * np.clip((DURATION - times) / 0.85, 0, 1) ** 1.4
    music *= fade[:, None]
    for start, depth in [(31.5, 0.25), (43.5, 0.72)]:
        distance = times - start
        envelope = np.exp(-np.maximum(distance, 0) * 9) * (distance >= 0)
        pre = np.exp(np.minimum(distance, 0) * 120) * (distance < 0)
        music *= (1 - depth * (envelope + pre))[:, None]
    effects, sync = sound_design(tones, cues, count)
    mix = music + effects
    peak = float(np.max(np.abs(mix)))
    master_gain = min(1, 0.89 / peak)
    mix *= master_gain
    write_wav(OUTPUT / "musique-originale.wav", music * master_gain)
    write_wav(OUTPUT / "bruitages.wav", effects * master_gain)
    write_wav(OUTPUT / "bande-son-originale.wav", mix)
    manifest = {"version": ROOT.name, "revision": 3, "duration": DURATION, "bpm": BPM, "sampleRate": RATE, "channels": 2, "originalComposition": True, "externalSamples": False, "foreignReferenceAudioUsed": False, "v3AudioUsed": False, "arrangement": "Organic broken beat, synthesized guitar strings, warm sustained chords, round syncopated bass, dry wood and snare percussion", "harmony": "Fmaj7 / Am9 / Cmaj9 / Gsus9, evolving 21-bar arrangement", "synchronizedEvents": len(sync), "finalMouseClick": {"time": FINAL_CLICK, "frame": 2610, "audioSample": 2088000, "musicDuckingDb": round(20 * math.log10(0.28), 2), "releaseDelay": 0.058}, "peakDbfs": float(20 * np.log10(np.max(np.abs(mix)))), "rmsDbfs": float(20 * np.log10(np.sqrt(np.mean(mix * mix)))), "stems": ["musique-originale.wav", "bruitages.wav", "clic-final.wav"]}
    (OUTPUT / "audio-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (OUTPUT / "sync-events.json").write_text(json.dumps({"sampleRate": RATE, "fps": 60, "samplesPerFrame": 800, "events": sync}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest))


if __name__ == "__main__":
    compose()
