from __future__ import annotations

import hashlib
import json
import re
import subprocess
import wave
import zipfile
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "exports"
FILM = OUTPUT / f"michel-djoumessi-{ROOT.name}.mp4"
ORIGINAL = ROOT.parent / "v3" / "exports" / "michel-djoumessi-v3-final.mp4"
ORIGINAL_HASH = "35db1e06b74bee8d79d7acd236129633ab067bfefcee56c46d3688644ecabcf2"
V4BIS_HASH = "2f19f4c7c765cc817d67ea398ecee4930b82d76d077f859f82254ecd6871fa51"
INITIAL_V4_HASH = "b348880d4686f2d8fd90f273661f67e1b138700d803d5906ed9af52ad977d490"
REVISION_02_HASH = "9a944d7e72ed72d9b981a2b87fb470461505ff3f7d1039cc4c4be923ebb05234"


def command(arguments: list[str]) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(arguments, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    if result.returncode != 0:
        raise RuntimeError(result.stderr[-4000:])
    return result


def pcm(filename: Path) -> np.ndarray:
    with wave.open(str(filename), "rb") as source:
        if source.getframerate() != 48000 or source.getnchannels() != 2:
            raise ValueError("Format sonore inattendu")
        return np.frombuffer(source.readframes(source.getnframes()), dtype="<i2").reshape(-1, 2)


def similarity(new_start: float, old_start: float, duration: float) -> float:
    result = command(["ffmpeg", "-hide_banner", "-ss", str(new_start), "-i", str(FILM), "-ss", str(old_start), "-i", str(ORIGINAL), "-filter_complex", "[0:v]setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[a][b]ssim", "-t", str(duration), "-an", "-f", "null", "-"])
    matches = re.findall(r"All:([0-9.]+)", result.stderr)
    if not matches:
        raise ValueError("La comparaison du master n’a pas produit de mesure")
    value = float(matches[-1])
    assert value > 0.995, f"La reprise du master diffère trop : SSIM {value}"
    return value


def high_pass(signal: np.ndarray) -> np.ndarray:
    spectrum = np.fft.rfft(signal)
    spectrum[np.fft.rfftfreq(len(signal), 1 / 48000) < 1700] = 0
    return np.fft.irfft(spectrum, n=len(signal))


def verify_final_click() -> dict:
    result = subprocess.run(["ffmpeg", "-v", "error", "-ss", "43.45", "-i", str(FILM), "-t", "0.3", "-vn", "-ar", "48000", "-ac", "2", "-f", "f32le", "pipe:1"], capture_output=True, check=True)
    decoded = np.frombuffer(result.stdout, dtype="<f4").reshape(-1, 2).mean(axis=1)
    template = np.zeros(len(decoded))
    click = pcm(OUTPUT / "clic-final.wav").mean(axis=1) / 32767
    template[2400:2400 + len(click)] = click
    decoded = high_pass(decoded)
    template = high_pass(template)
    correlations = [(lag, float(np.dot(decoded, np.roll(template, lag)) / max(np.linalg.norm(decoded) * np.linalg.norm(template), 1e-9))) for lag in range(-96, 97)]
    lag, correlation = max(correlations, key=lambda pair: pair[1])
    assert correlation > 0.35, f"Clic final insuffisamment distinct dans l’AAC : {correlation}"
    assert abs(lag) < 96, f"Clic final décalé : {lag} échantillons"
    return {"time": 43.5, "frame": 2610, "aacTemplateCorrelation": correlation, "lagSamples": lag, "lagMilliseconds": lag / 48, "decodedPeakDbfs": float(20 * np.log10(np.max(np.abs(decoded))))}


def verify() -> None:
    probe = json.loads(command(["ffprobe", "-v", "error", "-count_frames", "-show_streams", "-show_format", "-of", "json", str(FILM)]).stdout)
    video = next(stream for stream in probe["streams"] if stream["codec_type"] == "video")
    audio = next(stream for stream in probe["streams"] if stream["codec_type"] == "audio")
    assert (video["width"], video["height"]) == (1920, 1080)
    assert video["avg_frame_rate"] == "60/1"
    assert int(video["nb_read_frames"]) == 2700
    assert abs(float(video["duration"]) - 45) < 0.001
    assert abs(float(audio["duration"]) - 45) < 0.03
    assert audio["channels"] == 2 and audio["sample_rate"] == "48000"
    assert video["codec_name"] == "h264" and audio["codec_name"] == "aac"
    decode = command(["ffmpeg", "-v", "error", "-i", str(FILM), "-f", "null", "-"])
    if decode.stderr.strip():
        raise ValueError(decode.stderr)
    original_hash = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
    assert original_hash == ORIGINAL_HASH
    v4bis_hash = hashlib.sha256((ROOT.parent / "v4bis" / "exports" / "michel-djoumessi-v4bis.mp4").read_bytes()).hexdigest()
    assert v4bis_hash == V4BIS_HASH
    with zipfile.ZipFile(ROOT / "history" / "v4-initiale.zip") as backup:
        entry = next(name for name in backup.namelist() if name.endswith("michel-djoumessi-v4.mp4"))
        assert hashlib.sha256(backup.read(entry)).hexdigest() == INITIAL_V4_HASH
    with zipfile.ZipFile(ROOT / "history" / "v4-revision-02.zip") as backup:
        entry = next(name for name in backup.namelist() if name.endswith("michel-djoumessi-v4.mp4"))
        assert hashlib.sha256(backup.read(entry)).hexdigest() == REVISION_02_HASH
    score = pcm(OUTPUT / "bande-son-originale.wav")
    old_score = pcm(ORIGINAL.parent / "bande-son-originale.wav")
    assert len(score) == 45 * 48000
    music = pcm(OUTPUT / "musique-originale.wav")
    effects = pcm(OUTPUT / "bruitages.wav")
    assert np.max(np.abs(score.astype(np.int32) - music.astype(np.int32) - effects.astype(np.int32))) <= 1
    correlation = float(np.corrcoef(music[:len(old_score), 0], old_score[:, 0])[0, 1])
    assert abs(correlation) < 0.1
    assert not np.array_equal(score[1656000:], old_score[1416000:])
    click_report = verify_final_click()
    motion = json.loads((OUTPUT / "motion-cues.json").read_text(encoding="utf-8"))
    sound = json.loads((OUTPUT / "sync-events.json").read_text(encoding="utf-8"))
    assert len(motion["cues"]) == len(sound["events"])
    assert all(event["audioSample"] == event["frame"] * 800 for event in sound["events"])
    assert all(event["frame"] < 2700 for event in sound["events"])
    final_click = next(event for event in sound["events"] if event["frame"] == 2610)
    assert final_click["kind"] == "click" and final_click["audioSample"] == 2088000
    windows = score.astype(np.float64).reshape(-1, 12000, 2) / 32767
    rms = np.sqrt(np.mean(windows * windows, axis=(1, 2)))
    assert float(np.min(rms[1:-2])) > 0.003
    opening_ssim = similarity(0, 0, 4)
    ending_ssim = similarity(34.5, 29.5, 10.5)
    sources = json.loads((OUTPUT / "sources.json").read_text(encoding="utf-8"))
    assert sources["opening"]["duration"] == 4
    assert sources["ending"]["originalStart"] == 29.5
    assert sources["removedV3Sequence"] == {"start": 26.5, "end": 29.5, "name": "Du mouvement · Design Motion Web"}
    assert sources["replacedRevision2Sequence"]["start"] == 31.5
    assert sources["pointer"] == "mouse"
    report = {"version": ROOT.name, "revision": 3, "duration": 45, "resolution": [1920, 1080], "fps": 60, "frames": 2700, "audio": {"channels": 2, "sampleRate": 48000, "codec": "aac", "entirelyNewScore": True, "musicCorrelationWithV3": correlation, "musicAndEffectsSumVerified": True, "finalMouseClick": click_report, "minimumQuarterSecondRmsDbfs": float(20 * np.log10(np.min(rms[1:-2]))), "synchronizedEvents": len(sound["events"]), "samplesPerFrame": 800}, "fullDecode": "passed", "v3Unchanged": original_hash, "v4bisUnchanged": v4bis_hash, "initialV4BackupVerified": True, "revision02BackupVerified": True, "v3Opening": {"start": 0, "duration": 4, "ssim": opening_ssim, "originalAnimation": True}, "preservedPictureTail": {"oldStart": 29.5, "newStart": 34.5, "duration": 10.5, "ssim": ending_ssim, "reencoded": True}, "removedSequence": "Ça marche · remplacement par assemblage du logo", "bytes": FILM.stat().st_size, "sha256": hashlib.sha256(FILM.read_bytes()).hexdigest()}
    (OUTPUT / "verification-technique.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    verify()
