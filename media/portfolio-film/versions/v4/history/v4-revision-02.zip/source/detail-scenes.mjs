import { palette, circle } from './graphics.mjs';
import { stage, beat, blend, headline } from './motion-kit.mjs';
import { curvePoint, sceneLayer } from './signal-language.mjs';
import { compositionScene, typographyScene } from './design-scenes.mjs';
import { pythonScene, deploymentScene, cloudScene, qualityScene, payoffScene, SHIPPING_ROUTE } from './delivery-scenes.mjs';

export const detailCues = [
  [4, 'hit', 'Entrer dans la composition'], [4.6, 'sweep', 'Suivre le point'], [5.6, 'click', 'Ajuster le détail'],
  [6, 'tick', 'Aligner les angles'], [6.25, 'tick', 'Propager l’alignement'], [7, 'tone', 'Reculer pour vérifier'],
  [8.25, 'sweep', 'Entrer dans la forme'], [8.8, 'logo', 'Figma'], [9.35, 'tick', 'Tracer la courbe'],
  [9.6, 'click', 'Ajuster la poignée'], [10.25, 'tone', 'Équilibrer les formes'], [11.75, 'sweep', 'La forme devient un fichier'],
  [12, 'logo', 'Python'], [12.5, 'tick', 'Lire les fichiers'], [13.15, 'tick', 'Trier'], [13.8, 'click', 'Préparer la publication'],
  [14.5, 'tick', 'Assembler les ressources'], [15.25, 'tick', 'Vérifier le paquet'], [15.75, 'tone', 'Prêt à publier'],
  [16.75, 'sweep', 'Le code quitte le PC'], [17.35, 'logo', 'Next.js et TypeScript'], [17.85, 'click', 'Transmettre'],
  [18.2, 'tick', 'Suivre le paquet'], [19.15, 'hit', 'Le serveur reçoit'], [19.5, 'tick', 'Activer les services'],
  [20, 'tick', 'Le serveur répond'], [20.75, 'tone', 'Déploiement prêt'], [22.25, 'sweep', 'Rejoindre le cloud'],
  [22.8, 'tone', 'Publier'], [23.75, 'sweep', 'Le cloud se déploie'], [24.25, 'tick', 'Ouvrir les connexions'],
  [25, 'tick', 'Première connexion'], [25.5, 'tick', 'Deuxième connexion'], [26, 'tone', 'Accessible'],
  [27.75, 'sweep', 'Vérifier le chemin'], [28, 'tick', 'Préparer'], [28.5, 'click', 'Corriger le passage'],
  [29, 'tick', 'Connecter'], [29.5, 'tick', 'Vérifier'], [30, 'tone', 'Publier'],
  [31.5, 'hit', 'Ça marche'], [31.8, 'sweep', 'Construire la validation'], [32.9, 'tone', 'Jusqu’au dernier détail'],
  [34, 'sweep', 'Retrouver la signature'],
];

export const detailTimeline = [
  [0, 4, 'Ouverture originale V3 · Michel Djoumessi'], [4, 8.25, 'Ajuster la composition'],
  [8.25, 11.75, 'Affiner une forme'], [11.75, 16.75, 'Python · préparer et organiser'],
  [16.75, 22.25, 'Du PC aux serveurs'], [22.25, 27.75, 'Du cloud au monde'],
  [27.75, 31.5, 'Vérifier et relier'], [31.5, 34.5, 'Ça marche · le résultat'],
];

const ANCHORS = [
  [4, 1610, 390], [4.6, 1470, 580], [5.6, 1125, 650], [6, 1140, 640], [6.75, 1550, 820],
  [7.5, 1570, 430], [8.25, 1490, 510], [8.8, 1470, 490], [9.6, 1380, 490], [10.25, 1350, 490],
  [11, 1220, 740], [11.75, 410, 525], [12.5, 460, 525], [13.15, 430, 595], [13.8, 820, 655],
  [14.5, 1410, 615], [15.25, 1490, 610], [15.75, 1490, 610], [16.75, 640, 600], [17.85, 635, 600],
  [19.15, 1180, 540], [20, 1370, 490], [21, 1450, 710], [22.25, 1320, 600], [22.8, 960, 690],
  [23.75, 960, 500], [24.5, 1170, 545], [25.5, 1530, 600], [26.5, 1440, 815], [27.75, 330, 600],
  [28.55, 700, 600], [29.8, 1120, 600], [30.5, 1590, 600], [31.5, 960, 630],
];

function conductorPosition(time) {
  if (time >= 17.85 && time <= 19.15) return curvePoint(SHIPPING_ROUTE, (time - 17.85) / 1.3);
  if (time >= 28.55 && time <= 29.8) return curvePoint([[700, 600], [830, 320], [1020, 340], [1120, 600]], (time - 28.55) / 1.25);
  if (time <= ANCHORS[0][0]) return { x: ANCHORS[0][1], y: ANCHORS[0][2] };
  for (let i = 1; i < ANCHORS.length; i += 1) {
    const [end, x, y] = ANCHORS[i];
    if (time > end) continue;
    const [start, oldX, oldY] = ANCHORS[i - 1];
    const p = beat(time, start, end - start);
    const swing = Math.sin(p * Math.PI) * Math.min(85, Math.hypot(x - oldX, y - oldY) * 0.15);
    return { x: blend(oldX, x, p), y: blend(oldY, y, p) - swing };
  }
  return { x: 960, y: 630 };
}

function conductor(ctx, time) {
  const alpha = beat(time, 4, 0.35) * (1 - beat(time, 31.1, 0.4));
  if (alpha <= 0) return;
  ctx.save();
  ctx.globalAlpha = alpha;
  for (let i = 8; i >= 1; i -= 1) {
    const point = conductorPosition(time - i * 0.023);
    ctx.save();
    ctx.globalAlpha = (1 - i / 9) * 0.22;
    circle(ctx, point.x, point.y, 13 - i * 0.8, palette.green);
    ctx.restore();
  }
  const point = conductorPosition(time);
  circle(ctx, point.x, point.y, 26 + Math.sin(time * Math.PI * 4) * 3, '#c4d9c199');
  circle(ctx, point.x, point.y, 13, palette.green);
  circle(ctx, point.x - 3, point.y - 4, 3, '#fff');
  ctx.restore();
}

export function drawDetail(ctx, time, assets) {
  if (time < 4) {
    ctx.drawImage(time > 2.5 ? assets.introLate : assets.introPreview, 0, 0, 1920, 1080);
    return 'Ouverture V3';
  }
  const payoff = time >= 31.5;
  stage(ctx, assets, payoff);
  if (payoff) payoffScene(ctx, time);
  else {
    sceneLayer(ctx, time, 4, 8.75, () => compositionScene(ctx, time, assets));
    sceneLayer(ctx, time, 8.25, 12.25, () => typographyScene(ctx, time, assets));
    sceneLayer(ctx, time, 11.75, 17.25, () => pythonScene(ctx, time, assets));
    sceneLayer(ctx, time, 16.75, 22.75, () => deploymentScene(ctx, time, assets));
    sceneLayer(ctx, time, 22.25, 28.25, () => cloudScene(ctx, time));
    sceneLayer(ctx, time, 27.75, 31.5, () => qualityScene(ctx, time));
    const heading = time < 11.75 ? 'ENCORE UN DÉTAIL.' : time < 22.25 ? 'UNE IDÉE DOIT AUSSI FONCTIONNER.' : 'ET TROUVER SA PLACE.';
    const start = time < 11.75 ? 4 : time < 22.25 ? 11.75 : 22.25;
    const zoom = beat(time, 4.45, 0.7) * (1 - beat(time, 6.7, 0.7));
    ctx.save();
    ctx.globalAlpha = 1 - zoom;
    headline(ctx, heading, 145, 250, heading.length > 27 ? 68 : 102, time - start);
    ctx.restore();
    conductor(ctx, time);
  }
  return detailTimeline.find(([start, end]) => time >= start && time < end)?.[2] ?? 'Final V3';
}
