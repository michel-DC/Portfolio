# V4 — Encore un détail

Révision 2. Film de 45 secondes, 1920 × 1080, 60 images/s, stéréo 48 kHz.

Les quatre premières secondes sont reprises directement du film V3 : nom complet, cadrage, polices et animation d’origine. Le nouvel arrangement musical commence par une phrase de piano ascendante et rejoint une pulsation plus affirmée à quatre secondes, au même tempo de 120 BPM.

Un point guide le parcours : ajustement d’une composition, travail d’une forme typographique, préparation de ressources avec un court script Python, transfert du PC aux serveurs, ouverture au cloud et vérification des connexions. Le responsive et les présentations répétées de pages ont été remplacés par ces situations. Les mouvements ont des conséquences : aligner, tracer, assembler, transmettre, activer, relier et valider.

À 31,5–34,5 secondes, « Ça marche » et une validation animée remplacent intégralement « Du mouvement » et ses panneaux Design/Motion/Web. Les 10,5 dernières secondes reprennent les outils, les verbes, la signature et l’invitation de la V3, de 29,5–40 secondes à 34,5–45 secondes. Le son conserve le même décalage de cinq secondes. Le raccord musical progressif se situe avant ce bloc ; sa piste PCM est conservée à l’échantillon près avant compression AAC.

L’ouverture et le final sont réencodés depuis le master V3, sans refaire leur animation, puis comparés avec lui. Le site, la V3 et la V4bis restent inchangés. La première V4 et ses sources sont sauvegardées dans `history/v4-initiale.zip`.

## Fichiers

- `exports/michel-djoumessi-v4.mp4` : film.
- `exports/bande-son-originale.wav` : piste sonore complète.
- `exports/storyboard.jpg` : planche des nouvelles séquences.
- `exports/motion-cues.json` et `exports/sync-events.json` : repères partagés par le son et l’image.
- `exports/verification-technique.json` : contrôles du fichier, de la synchronisation et du final.
- `review/` : captures de contrôle.

## Reproduction

Depuis ce dossier, avec Node.js, FFmpeg, Python et NumPy :

```powershell
$env:MEDIA_NODE_MODULES='C:/Users/djoum/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
pnpm preview
python source/score.py
pnpm render
python source/verify-film.py
```

Les polices, la texture et les logos sont chargés depuis les ressources du portfolio. La V3 archivée fournit les instruments sonores et le final commun. Aucun média issu des références externes n’est incorporé.
