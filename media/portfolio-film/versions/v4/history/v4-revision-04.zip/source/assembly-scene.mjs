import { palette } from './graphics.mjs';
import { line, pointer } from './film-language.mjs';
import { beat, blend, transform } from './motion-kit.mjs';

const TILE = 210;
const ORIGINS = [[-450, -230], [410, -260], [-390, 245], [400, 185]];

export function assemblyScene(ctx, time, assets) {
  const t = time - 31.5;
  const lock = beat(t, 1.1, 0.3);
  const leave = beat(t, 2.35, 0.65);
  const size = Math.min(370 / assets.logo.width, 370 / assets.logo.height);
  transform(ctx, { x: 960, y: 570, scale: 1 + lock * 0.08, alpha: 1 - leave }, () => {
    ctx.save();
    ctx.globalAlpha *= 1 - lock;
    for (const offset of [-TILE, 0, TILE]) {
      line(ctx, -650, offset, 650, offset, '#a5bdaf', 1, true);
      line(ctx, offset, -350, offset, 350, '#a5bdaf', 1, true);
    }
    ctx.restore();
    ORIGINS.forEach(([originX, originY], index) => {
      const row = Math.floor(index / 2);
      const column = index % 2;
      const targetX = (column - 0.5) * TILE;
      const targetY = (row - 0.5) * TILE;
      const progress = beat(t, index === 3 ? 0.3 : index * 0.09, index === 3 ? 0.8 : 0.7);
      const x = blend(originX, targetX, progress);
      const y = blend(originY, targetY, progress);
      transform(ctx, { x, y, angle: (1 - progress) * [0.1, -0.12, -0.08, 0.09][index] }, () => {
        ctx.save();
        ctx.beginPath();
        ctx.rect(-TILE / 2, -TILE / 2, TILE, TILE);
        ctx.clip();
        ctx.drawImage(assets.logo, -assets.logo.width * size / 2 - targetX, -assets.logo.height * size / 2 - targetY, assets.logo.width * size, assets.logo.height * size);
        ctx.restore();
      });
    });
    if (lock > 0 && lock < 1) {
      ctx.strokeStyle = palette.green;
      ctx.lineWidth = 2;
      ctx.globalAlpha *= 1 - lock;
      const expansion = TILE + lock * 90;
      ctx.strokeRect(-expansion, -expansion, expansion * 2, expansion * 2);
    }
  });
  const drag = beat(t, 0.3, 0.8);
  const exit = beat(t, 1.45, 0.65);
  const x = blend(blend(1360, 1065, drag), 1490, exit);
  const y = blend(blend(755, 675, drag), 910, exit);
  ctx.save();
  ctx.globalAlpha = beat(t, 0, 0.15) * (1 - exit);
  pointer(ctx, x, y, t >= 0.3 && t < 0.52 ? (t - 0.3) / 0.22 : 0);
  ctx.restore();
}
