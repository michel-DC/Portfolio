from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np
from numpy.typing import NDArray


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "exports"
WORK = ROOT / ".work"
TRACK = ROOT / "assets" / "cat-walk-arulo-mixkit-371.mp3"
RATE = 48_000
DURATION = 45
BPM = 120
FloatArray = NDArray[np.float64]
SECTIONS = [
    (0, 4, 28, 1.3, "Ouverture en montée"),
    (4, 11.75, 32, 0.74, "Premier drop · composition et courbe"),
    (11.75, 16.75, 40, 0.74, "Reprise · Python"),
    (16.75, 22.25, 50, 0.76, "Reprise · déploiement"),
    (22.25, 27.75, 56, 0.76, "Ouverture · cloud"),
    (27.75, 31.5, 72, 1.2, "Retrait · vérification"),
    (31.5, 34.5, 93, 1.3, "Montée · assemblage du logo"),
    (34.5, 41.5, 96, 0.76, "Second drop · outils et signature"),
    (41.5, 43.5, 118, 0.72, "Invitation finale"),
    (43.5, 45, 120, 0.65, "Clic et résolution"),
]
sys.dont_write_bytecode = True


def instruments():
    specification = importlib.util.spec_from_file_location("sound_palette", ROOT / "source" / "sound-palette.py")
    if specification is None or specification.loader is None:
        raise RuntimeError("Palette de bruitages introuvable")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def add(track: FloatArray, signal: FloatArray, start: float, gain: float, pan: float = 0) -> None:
    offset = round(start * RATE)
    if offset < 0 or offset >= len(track):
        return
    length = min(len(signal), len(track) - offset)
    angle = (pan + 1) * math.pi / 4
    track[offset:offset + length, 0] += signal[:length] * gain * math.cos(angle)
    track[offset:offset + length, 1] += signal[:length] * gain * math.sin(angle)


def read_wav(filename: Path) -> FloatArray:
    with wave.open(str(filename), "rb") as source:
        if source.getframerate() != RATE or source.getnchannels() != 2 or source.getsampwidth() != 2:
            raise ValueError("Format PCM inattendu")
        return np.frombuffer(source.readframes(source.getnframes()), dtype="<i2").reshape(-1, 2).astype(np.float64) / 32767


def write_wav(filename: Path, samples: FloatArray) -> None:
    pcm = np.rint(np.clip(samples, -0.999, 0.999) * 32767).astype("<i2")
    with wave.open(str(filename), "wb") as output:
        output.setnchannels(2)
        output.setsampwidth(2)
        output.setframerate(RATE)
        output.writeframes(pcm.tobytes())


def edit_music() -> FloatArray:
    WORK.mkdir(exist_ok=True)
    retimed = WORK / "cat-walk-120.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(TRACK), "-af", "atempo=0.9230769231", "-ar", str(RATE), "-ac", "2", "-c:a", "pcm_s16le", str(retimed)], check=True)
    source = read_wav(retimed)
    music = np.zeros((DURATION * RATE, 2))
    for start, end, original_start, gain, _ in SECTIONS:
        count = round((end - start) * RATE)
        segment = source[round(original_start * RATE):round(original_start * RATE) + count].copy()
        if len(segment) != count:
            raise ValueError("Segment musical incomplet")
        envelope = np.ones(count)
        attack = round(0.002 * RATE)
        release = round(0.012 * RATE)
        envelope[:attack] = np.linspace(0, 1, attack)
        envelope[-release:] = np.linspace(1, 0, release)
        music[round(start * RATE):round(end * RATE)] = segment * (envelope * gain)[:, None]
    times = np.arange(len(music)) / RATE
    for start, depth, recovery in [(31.8, 0.22, 12), (32.6, 0.3, 9), (43.5, 0.9, 6)]:
        distance = times - start
        envelope = np.exp(-np.maximum(distance, 0) * recovery) * (distance >= 0) + np.exp(np.minimum(distance, 0) * 150) * (distance < 0)
        music *= (1 - depth * envelope)[:, None]
    music *= np.clip((DURATION - times) / 0.65, 0, 1)[:, None]
    return music


def sound_design(tones, cues: dict, count: int) -> tuple[FloatArray, list[dict]]:
    effects = np.zeros((count, 2))
    sync = []
    mouse = tones.mouse_click()
    for index, event in enumerate(cues["cues"]):
        position = event["frame"] / 60
        sync.append({**event, "audioTime": position, "audioSample": event["frame"] * 800})
        kind = event["kind"]
        pan = math.sin(index * 0.6) * 0.28
        if kind == "click":
            add(effects, mouse, position, 0.73 if position == 43.5 else 0.25, 0)
        elif kind == "sweep":
            add(effects, tones.air(0.3), max(0, position - 0.2), 0.26, pan)
        elif kind in ("hit", "cut"):
            add(effects, tones.kick(), position, 0.21)
        elif kind in ("tick", "letter", "logo"):
            add(effects, tones.wood(), position, 0.085 if kind != "letter" else 0.035, pan)
    for start, _, _, _, _ in SECTIONS[1:]:
        add(effects, tones.kick(), start, 0.23)
        if start != 43.5:
            add(effects, tones.air(0.4), start - 0.32, 0.19, -0.2)
    write_wav(OUTPUT / "clic-final.wav", np.column_stack([mouse, mouse]) * 0.73 / math.sqrt(2))
    return effects, sync


def compose() -> None:
    tones = instruments()
    cues = json.loads((OUTPUT / "motion-cues.json").read_text(encoding="utf-8"))
    music = edit_music()
    effects, sync = sound_design(tones, cues, len(music))
    mix = music + effects
    gain = min(1, 0.89 / max(float(np.max(np.abs(mix))), 1e-9))
    mix *= gain
    write_wav(OUTPUT / "musique-mixkit-montage.wav", music * gain)
    write_wav(OUTPUT / "bruitages.wav", effects * gain)
    write_wav(OUTPUT / "bande-son-originale.wav", mix)
    manifest = {"version": ROOT.name, "revision": 4, "duration": DURATION, "bpm": BPM, "sampleRate": RATE, "channels": 2, "originalComposition": False, "musicSource": {"title": "Cat Walk", "artist": "Arulo", "library": "Mixkit", "id": 371, "page": "https://mixkit.co/free-stock-music/edm/", "audioUrl": "https://assets.mixkit.co/music/371/371.mp3", "license": "Mixkit Stock Music Free License", "licenseUrl": "https://mixkit.co/license/#musicFree", "sha256": hashlib.sha256(TRACK.read_bytes()).hexdigest(), "sourceBpm": 130, "editedBpm": BPM, "tempoAdjustedWithoutPitchChange": True}, "v3AudioUsed": False, "synchronizedEvents": len(sync), "musicalSections": [{"start": start, "end": end, "sourceStartAfterTempoAdjustment": source_start, "gain": level, "name": name} for start, end, source_start, level, name in SECTIONS], "finalMouseClick": {"time": 43.5, "frame": 2610, "audioSample": 2088000, "musicDuckingDb": -20, "releaseDelay": 0.058}, "peakDbfs": float(20 * np.log10(np.max(np.abs(mix)))), "rmsDbfs": float(20 * np.log10(np.sqrt(np.mean(mix * mix)))), "stems": ["musique-mixkit-montage.wav", "bruitages.wav", "clic-final.wav"], "workingStemsForVideoProductionOnly": True}
    (OUTPUT / "audio-manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (OUTPUT / "sync-events.json").write_text(json.dumps({"sampleRate": RATE, "fps": 60, "samplesPerFrame": 800, "events": sync}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest))


if __name__ == "__main__":
    compose()
