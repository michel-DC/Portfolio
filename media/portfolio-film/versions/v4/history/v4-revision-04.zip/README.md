# V4 — Encore un détail

Révision 4. Film de 45 secondes, 1920 × 1080, 60 images/s, stéréo 48 kHz.

Les quatre rectangles blancs de l’assemblage du logo ont été retirés. Le SVG du portfolio était déjà transparent : il n’a pas été modifié. Ses fragments se réunissent directement sur la texture du film.

La musique de la révision 3 a été remplacée par **Cat Walk, d’Arulo**, fournie par Mixkit sous la Mixkit Stock Music Free License. Ce morceau n’est pas une composition originale de Michel ou de Codex. Les sources et les conditions consultées sont documentées dans assets/music-license.md.

Le montage musical est adapté à l’image : montée de 0 à 4 secondes, premier drop, reprises aux entrées de Python, du déploiement et du cloud, retrait pendant la vérification, montée sur l’assemblage du logo, second drop sur les outils et la signature, puis résolution finale. Le tempo passe de 130 à 120 BPM sans changement de hauteur. Les dix sections suivent les changements du film. Les 76 bruitages partagent les repères de l’image. Le clic mécanique final est conservé à 43,5 secondes ; la musique s’atténue autour de cet appui.

L’ouverture originale de quatre secondes et les images des 10,5 dernières secondes restent celles de la V3. Le montage visuel et sa durée restent identiques à la révision 3, hors suppression du fond blanc du logo. Le site, la V3 et la V4bis restent inchangés.

## Fichiers

- exports/michel-djoumessi-v4.mp4 : film avec le nouveau montage musical.
- exports/bande-son-originale.wav : mixage complet, nom historique du fichier de production ; la musique est créditée à Arulo.
- exports/musique-mixkit-montage.wav : piste musicale de travail pour le montage vidéo.
- exports/bruitages.wav et exports/clic-final.wav : bruitages.
- exports/audio-manifest.json : morceau, artiste, source, empreinte, sections et repères.
- exports/storyboard.jpg : planche des séquences.
- exports/verification-technique.json et review/verification.md : contrôles.
- history/v4-initiale.zip, history/v4-revision-02.zip et history/v4-revision-03.zip : sauvegardes avec sources et exports.

Les pistes de travail servent à reproduire la vidéo. Elles ne sont pas destinées à une publication musicale séparée.

## Reproduction

Depuis ce dossier, avec Node.js, FFmpeg, Python et NumPy :

```powershell
$env:MEDIA_NODE_MODULES='C:/Users/djoum/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
pnpm preview
python source/score.py
pnpm render
python source/verify-film.py
```

Les polices, la texture et les logos viennent du portfolio. La musique source se trouve dans assets/cat-walk-arulo-mixkit-371.mp3. La V3 archivée fournit uniquement les images d’ouverture et de final.
