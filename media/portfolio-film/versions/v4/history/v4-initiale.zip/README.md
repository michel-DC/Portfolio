# V4 — Encore un détail

Film de comparaison de 45 secondes, 1920 × 1080, 60 images/s, stéréo 48 kHz.

Le début suit une composition : alignement, travail des formes, adaptation du format, interaction, organisation avec Python, puis synthèse. Le récit exprime le soin porté à l’expérience. Les outils apparaissent pendant leur action. Aucun projet n’est présenté comme une prestation.

Les 13,5 dernières secondes reprennent le final officiel V3, de 26,5 à 40 secondes, déplacé à 31,5–45 secondes. Ses images sont réencodées avec une comparaison SSIM ; sa piste sonore PCM est conservée à l’échantillon près avant compression AAC. Le raccord musical progressif se trouve avant ce bloc. La V3 et le site restent inchangés.

## Fichiers

- `exports/michel-djoumessi-v4.mp4` : film.
- `exports/bande-son-originale.wav` : piste sonore complète.
- `exports/storyboard.jpg` : planche des nouvelles séquences.
- `exports/motion-cues.json` et `exports/sync-events.json` : repères partagés par le son et l’image.
- `exports/verification-technique.json` : contrôles du fichier, de la synchronisation et du final.
- `review/` : captures de contrôle.

## Reproduction

Depuis ce dossier, avec Node.js, FFmpeg, Python et NumPy :

```powershell
$env:MEDIA_NODE_MODULES='C:/Users/djoum/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
pnpm preview
python source/score.py
pnpm render
python source/verify-film.py
```

Les polices, la texture et les logos sont chargés depuis les ressources du portfolio. La V3 archivée fournit les instruments sonores et le final commun. Aucun média issu des références externes n’est incorporé.
