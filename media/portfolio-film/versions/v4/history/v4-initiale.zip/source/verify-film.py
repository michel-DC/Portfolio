from __future__ import annotations

import hashlib
import json
import re
import subprocess
import wave
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "exports"
FILM = OUTPUT / f"michel-djoumessi-{ROOT.name}.mp4"
ORIGINAL = ROOT.parent / "v3" / "exports" / "michel-djoumessi-v3-final.mp4"
ORIGINAL_HASH = "35db1e06b74bee8d79d7acd236129633ab067bfefcee56c46d3688644ecabcf2"


def command(arguments: list[str]) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(arguments, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    if result.returncode != 0:
        raise RuntimeError(result.stderr[-4000:])
    return result


def pcm(filename: Path) -> np.ndarray:
    with wave.open(str(filename), "rb") as source:
        if source.getframerate() != 48000 or source.getnchannels() != 2:
            raise ValueError("Format sonore inattendu")
        return np.frombuffer(source.readframes(source.getnframes()), dtype="<i2").reshape(-1, 2)


def verify() -> None:
    probe = json.loads(command(["ffprobe", "-v", "error", "-count_frames", "-show_streams", "-show_format", "-of", "json", str(FILM)]).stdout)
    video = next(stream for stream in probe["streams"] if stream["codec_type"] == "video")
    audio = next(stream for stream in probe["streams"] if stream["codec_type"] == "audio")
    assert (video["width"], video["height"]) == (1920, 1080)
    assert video["avg_frame_rate"] == "60/1"
    assert int(video["nb_read_frames"]) == 2700
    assert abs(float(video["duration"]) - 45) < 0.001
    assert abs(float(audio["duration"]) - 45) < 0.03
    assert audio["channels"] == 2 and audio["sample_rate"] == "48000"
    assert video["codec_name"] == "h264" and audio["codec_name"] == "aac"
    decode = command(["ffmpeg", "-v", "error", "-i", str(FILM), "-f", "null", "-"])
    if decode.stderr.strip():
        raise ValueError(decode.stderr)
    original_hash = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
    assert original_hash == ORIGINAL_HASH
    score = pcm(OUTPUT / "bande-son-originale.wav")
    old_score = pcm(ORIGINAL.parent / "bande-son-originale.wav")
    assert len(score) == 45 * 48000
    assert np.array_equal(score[1512000:], old_score[1272000:])
    motion = json.loads((OUTPUT / "motion-cues.json").read_text(encoding="utf-8"))
    sound = json.loads((OUTPUT / "sync-events.json").read_text(encoding="utf-8"))
    assert len(motion["cues"]) == len(sound["events"])
    assert all(event["audioSample"] == event["frame"] * 800 for event in sound["events"])
    assert all(event["frame"] < 2700 for event in sound["events"])
    windows = score[:1512000].astype(np.float64).reshape(-1, 12000, 2) / 32767
    rms = np.sqrt(np.mean(windows * windows, axis=(1, 2)))
    assert float(np.min(rms[1:])) > 0.01
    comparison = command(["ffmpeg", "-hide_banner", "-ss", "31.5", "-i", str(FILM), "-ss", "26.5", "-i", str(ORIGINAL), "-filter_complex", "[0:v]setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[a][b]ssim", "-t", "13.5", "-an", "-f", "null", "-"])
    matches = re.findall(r"All:([0-9.]+)", comparison.stderr)
    if not matches:
        raise ValueError("La comparaison du final n’a pas produit de mesure")
    ssim = float(matches[-1])
    assert ssim > 0.995, f"Le final diffère trop du master : SSIM {ssim}"
    report = {"version": ROOT.name, "duration": 45, "resolution": [1920, 1080], "fps": 60, "frames": 2700, "audio": {"channels": 2, "sampleRate": 48000, "codec": "aac", "originalTailPcmIdentical": True, "minimumQuarterSecondRmsDbfs": float(20 * np.log10(np.min(rms[1:]))), "synchronizedEvents": len(sound["events"]), "samplesPerFrame": 800}, "fullDecode": "passed", "v3Unchanged": original_hash, "preservedPictureTail": {"oldStart": 26.5, "newStart": 31.5, "duration": 13.5, "ssim": ssim, "reencoded": True}, "bytes": FILM.stat().st_size, "sha256": hashlib.sha256(FILM.read_bytes()).hexdigest()}
    (OUTPUT / "verification-technique.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    verify()
