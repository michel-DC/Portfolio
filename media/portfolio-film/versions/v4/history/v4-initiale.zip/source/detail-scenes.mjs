import { palette, circle, clamp } from './graphics.mjs';
import { type, line, rounded, ornament } from './film-language.mjs';
import { stage, transform, beat, blend, spring, headline, label, token, guides, panel, identityOpening, endingWipe, cursorAt, rosette } from './motion-kit.mjs';

export const detailCues = [
  [0.25, 'letter', 'Le nom complet'], [1, 'tone', 'La signature'], [2.5, 'sweep', 'La composition entre'],
  [4, 'tick', 'Repérer le décalage'], [5.5, 'click', 'Ajuster le détail'], [6, 'tick', 'Aligner'],
  [7.5, 'sweep', 'Entrer dans la lettre'], [8.5, 'logo', 'Figma'], [9.5, 'tick', 'Ajuster la forme'],
  [11, 'sweep', 'Revenir à la composition'], [12.5, 'hit', 'Changer de format'], [14, 'tick', 'Trouver le passage'],
  [15.5, 'sweep', 'Déployer'], [17, 'logo', 'Next.js et TypeScript'], [18, 'click', 'Le geste répond'],
  [19, 'tone', 'La réaction'], [20.5, 'sweep', 'La répétition'], [21.5, 'logo', 'Python'],
  [22.5, 'tick', 'Un geste'], [23, 'tick', 'Plusieurs résultats'], [23.5, 'tick', 'La série'],
  [24, 'tone', 'Le flux est organisé'], [25.5, 'sweep', 'La composition se reconstruit'],
  [27, 'hit', 'Le détail fait l’expérience'], [28.5, 'tone', 'La forme aboutie'], [30.5, 'sweep', 'Vers le final'],
];

export const detailTimeline = [
  [0, 3, 'Michel Djoumessi'], [3, 7.5, 'Repérer et ajuster'], [7.5, 12, 'Le soin des formes'],
  [12, 17, 'Une composition qui s’adapte'], [17, 21, 'Une composition qui répond'],
  [21, 26, 'Simplifier avec Python'], [26, 31.5, 'Une expérience cohérente'],
];

function typographyDetail(ctx, assets, time, alpha) {
  if (alpha <= 0) return;
  const local = time - 7.5;
  const tracking = blend(100, 0, spring((local - 1.5) / 1));
  transform(ctx, { x: 960, y: 585, scale: 0.92 + beat(local, 0) * 0.08, alpha }, () => {
    rounded(ctx, -725, -290, 1450, 580, 8, '#f5f7f2', true);
    line(ctx, -640, 175, 640, 175, '#a4baac', 1);
    line(ctx, -640, -180, 640, -180, '#a4baac', 1);
    line(ctx, 0, -240, 0, 235, '#9caf9b', 1, true);
    const r = Math.sin(local * 1.8) * 0.025;
    transform(ctx, { x: -215 - tracking, y: 120, angle: r }, () => type(ctx, 'A', 0, 0, 430, { color: palette.green }));
    transform(ctx, { x: 200 + tracking, y: 120, angle: -r }, () => type(ctx, 'a', 0, 0, 430, { family: 'Amoria' }));
    const handleX = blend(565, 425, beat(local, 1.25, 1));
    const handleY = blend(-135, -80, beat(local, 1.25, 1));
    line(ctx, 260, -25, handleX, handleY, '#7b9c8a', 2);
    circle(ctx, handleX, handleY, 7, palette.green);
    cursorAt(ctx, handleX + 4, handleY + 4, beat(local, 1.75, 0.25));
    guides(ctx, 1310 - tracking, 430, 0.5);
    label(ctx, 'Les formes. Les espaces. Le bon équilibre.', 0, 252, beat(local, 0.7));
  });
  token(ctx, assets, 'figma', 150, 960, beat(local, 0.5), 'Figma');
}

function repeatedShapes(ctx, assets, time, alpha) {
  if (alpha <= 0) return;
  const local = time - 20.5;
  const organize = beat(local, 1.8, 2.1);
  const collapse = beat(local, 4.2, 1.1);
  transform(ctx, { x: 960, y: 590, alpha, scale: 1 - collapse * 0.15 }, () => {
    for (let index = 0; index < 60; index += 1) {
      const column = index % 10;
      const row = Math.floor(index / 10);
      const travel = beat(local, 0.2 + (index % 10) * 0.04, 0.8);
      const settled = beat(local, 1.8 + column * 0.075, 0.8);
      const dispersedX = Math.sin(index * 17.1) * 850;
      const dispersedY = Math.cos(index * 3.7) * 365;
      const gridX = (column - 4.5) * 127;
      const gridY = (row - 2.5) * 82;
      const x = blend(dispersedX, gridX, settled);
      const y = blend(dispersedY, gridY, settled);
      transform(ctx, { x: x * travel, y: y * travel, angle: (1 - settled) * Math.sin(index * 7) * 0.65, scale: travel * (1 - collapse) + collapse * 0.6, alpha: travel }, () => {
        rounded(ctx, -48, -27, 96, 54, 4, index % 4 === 0 ? palette.green : index % 3 === 0 ? '#b7cebe' : '#e4ece4', true);
        if (index % 4 === 0) ornament(ctx, 0, 0, 14, 1, organize, '#f6f8ef');
        else line(ctx, -26, 0, 26, 0, '#a1b7a7', 2);
      });
    }
    const ring = beat(local, 0.5) * (1 - beat(local, 4, 0.8));
    transform(ctx, { x: 0, y: 0, alpha: ring, scale: ring }, () => {
      circle(ctx, 0, 0, 90, '#fff');
      token(ctx, assets, 'python', 0, 0, 1);
      circle(ctx, 0, 0, 102 + Math.sin(local * 4) * 7, '#8ba594', true);
    });
  });
  label(ctx, organize > 0.7 ? 'Un geste. Soixante éléments à leur place.' : 'Faire une fois. Puis mieux faire.', 960, 970, alpha);
  token(ctx, assets, 'python', 150, 950, beat(local, 0.6) * alpha, 'Python');
}

export function drawDetail(ctx, time, assets) {
  stage(ctx, assets);
  const openingExit = identityOpening(ctx, assets, time);
  const enter = beat(time, 2.3, 1.1);
  const typography = beat(time, 7.5, 0.65) * (1 - beat(time, 11, 0.8));
  const automatic = beat(time, 20.5, 0.6) * (1 - beat(time, 25.5, 0.8));
  const zoomIn = beat(time, 3.9, 0.8) * (1 - beat(time, 6.5, 0.8));
  const adapt = beat(time, 12, 0.9) * (1 - beat(time, 15.5, 1.0));
  const align = spring((time - 5.5) / 0.75);
  const width = blend(1260, 470, adapt);
  const height = blend(570, 650, adapt);
  const click = beat(time, 18, 0.35);
  const panelAlpha = enter * (1 - typography) * (1 - automatic);
  if (time > 2.3) {
    const titleAlpha = enter * (1 - beat(time, 26, 0.8));
    transform(ctx, { x: 0, y: 0, alpha: titleAlpha * (1 - zoomIn) }, () => headline(ctx, 'ENCORE UN DÉTAIL.', 150, 273, 102, time - 2.7));
    const cameraX = 960 - zoomIn * 260;
    const cameraY = 635 + Math.sin(time * 0.7) * 7;
    const cameraScale = (0.74 + enter * 0.16 + zoomIn * 0.64) * (1 - beat(time, 29.4, 1.3) * 0.08);
    const rotation = (1 - enter) * -0.12 + Math.sin(time * 0.8) * 0.008 + adapt * -0.045;
    transform(ctx, { x: cameraX, y: cameraY, scale: cameraScale, angle: rotation, alpha: panelAlpha }, () => {
      if (adapt > 0.05) {
        for (const side of [-1, 1]) transform(ctx, { x: side * (width / 2 + 255), y: side * 35, angle: side * adapt * 0.09, scale: 0.8, alpha: adapt * 0.55 }, () => panel(ctx, assets, 400, 590, time + side));
      }
      const geometry = panel(ctx, assets, width, height, time, { aligned: clamp(align), active: beat(time, 8.5), interactive: click });
      const guidesAlpha = beat(time, 3.8) * (1 - beat(time, 7.1, 0.4));
      guides(ctx, width + 24, height + 24, guidesAlpha);
      if (guidesAlpha > 0) {
        const px = geometry.artX + blend(90, 0, beat(time, 4.5, 1));
        const py = geometry.artY + blend(130, 0, beat(time, 4.5, 1));
        circle(ctx, geometry.artX, geometry.artY, 120 - beat(time, 5.5) * 60, '#4a786377', true);
        cursorAt(ctx, px, py, beat(time, 5.5, 0.3), guidesAlpha);
        label(ctx, '24 px', 0, height / 2 + 55, guidesAlpha);
      }
      if (time > 16.5 && time < 21) {
        const arrival = beat(time, 17, 0.8);
        cursorAt(ctx, blend(700, geometry.buttonX + 45, arrival), blend(330, geometry.buttonY + 7, arrival), click, 1 - beat(time, 20.5));
        const wave = clamp((time - 18) / 1.3);
        if (wave > 0 && wave < 1) {
          ctx.save();
          ctx.globalAlpha = 1 - wave;
          circle(ctx, geometry.buttonX, geometry.buttonY, 30 + wave * 450, '#47765d', true);
          ctx.restore();
        }
      }
    });
    const note = time < 5.5 ? 'Voir ce qui peut encore évoluer.' : time < 12 ? 'Trouver le bon équilibre.' : time < 17 ? 'Garder l’intention. Changer de format.' : 'Le geste fait vivre la composition.';
    if (time < 20.5) label(ctx, note, 960, 980, titleAlpha * (1 - typography) * (1 - zoomIn));
  }
  typographyDetail(ctx, assets, time, typography);
  repeatedShapes(ctx, assets, time, automatic);
  if (time > 16.5 && time < 20.8) {
    const a = beat(time, 16.5) * (1 - beat(time, 20.2));
    token(ctx, assets, 'nextjs', 150, 950, a, 'Next.js');
    token(ctx, assets, 'typescript', 1640, 950, a, 'TypeScript');
  }
  if (time > 26) {
    const a = beat(time, 26, 0.8) * (1 - beat(time, 30.5));
    transform(ctx, { x: 0, y: 0, alpha: a }, () => {
      headline(ctx, 'LE DÉTAIL FAIT', 150, 247, 99, time - 26);
      headline(ctx, 'L’EXPÉRIENCE.', 150, 358, 109, time - 26.2);
    });
    const starExit = beat(time, 28.7, 1.5);
    transform(ctx, { x: blend(1555, 960, starExit), y: blend(335, 560, starExit), scale: blend(0.3, 1, starExit), alpha: a }, () => {
      rosette(ctx, 0, 0, 180, time);
      ornament(ctx, 0, 0, 55 + starExit * 50, 1, time * 0.3);
    });
    label(ctx, 'Regarder. Essayer. Ajuster.', 960, 985, a);
  }
  if (time < 3.1) ornament(ctx, blend(1580, 1350, openingExit), blend(325, 575, openingExit), 35 + openingExit * 25, beat(time, 0.8), time * 0.9);
  endingWipe(ctx, time);
  return detailTimeline.find(([start, end]) => time >= start && time < end)?.[2] ?? 'Vers le mouvement';
}
