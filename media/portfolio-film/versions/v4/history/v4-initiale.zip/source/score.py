from __future__ import annotations

import importlib.util
import json
import math
import sys
import wave
from pathlib import Path

import numpy as np
from numpy.typing import NDArray


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "exports"
ORIGINAL = ROOT.parent / "v3"
RATE = 48_000
DURATION = 45
JOIN = 31.5
OLD_JOIN = 26.5
BEAT = 0.5
FloatArray = NDArray[np.float64]
sys.dont_write_bytecode = True


def load_instruments():
    specification = importlib.util.spec_from_file_location("v3_instruments", ORIGINAL / "source" / "score.py")
    if specification is None or specification.loader is None:
        raise RuntimeError("Les instruments originaux sont indisponibles")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def add(track: FloatArray, signal: FloatArray, start: float, gain: float, pan: float = 0) -> None:
    offset = round(start * RATE)
    if offset < 0 or offset >= len(track):
        return
    length = min(len(signal), len(track) - offset)
    angle = (pan + 1) * math.pi / 4
    track[offset:offset + length, 0] += signal[:length] * gain * math.cos(angle)
    track[offset:offset + length, 1] += signal[:length] * gain * math.sin(angle)


def echo(track: FloatArray, duration: float, gain: float) -> FloatArray:
    offset = round(duration * RATE)
    result = np.zeros_like(track)
    result[offset:] = track[:-offset, ::-1] * gain
    return result


def read_wav(filename: Path) -> FloatArray:
    with wave.open(str(filename), "rb") as source:
        if source.getframerate() != RATE or source.getnchannels() != 2 or source.getsampwidth() != 2:
            raise ValueError("Le master sonore doit être stéréo PCM 48 kHz 16 bits")
        return np.frombuffer(source.readframes(source.getnframes()), dtype="<i2").reshape(-1, 2).astype(np.float64) / 32767


def write_wav(filename: Path, samples: FloatArray) -> None:
    pcm = np.rint(np.clip(samples, -0.999, 0.999) * 32767).astype("<i2")
    with wave.open(str(filename), "wb") as output:
        output.setnchannels(2)
        output.setsampwidth(2)
        output.setframerate(RATE)
        output.writeframes(pcm.tobytes())


def compose() -> None:
    instruments = load_instruments()
    journey = ROOT.name == "v4bis"
    cues = json.loads((OUTPUT / "motion-cues.json").read_text(encoding="utf-8"))
    samples = round(DURATION * RATE)
    harmony = np.zeros((samples, 2), dtype=np.float64)
    melody = np.zeros_like(harmony)
    rhythm = np.zeros_like(harmony)
    effects = np.zeros_like(harmony)
    chords = [[50, 57, 61, 64, 69], [47, 54, 57, 62, 66], [43, 50, 54, 57, 62], [45, 52, 57, 59, 64]]
    roots = [38, 35, 31, 33]
    patterns = [[74, 78, 81, 76, 78, 85], [74, 73, 69, 66, 69, 78], [74, 78, 81, 83, 81, 78], [76, 73, 69, 71, 73, 76]]
    progression = [0, 0, 1, 1, 2, 2, 3, 3, 0, 1, 2, 3, 0, 1, 2, 1]
    kick = instruments.kick()
    click = instruments.soft_click()
    for bar, chord_index in enumerate(progression):
        start = bar * 2
        add(harmony, instruments.pad(chords[chord_index], 2.9), start, 0.22, -0.12)
        if bar >= 6:
            add(harmony, instruments.pad([note + 12 for note in chords[chord_index]], 2.9), start + 0.025, 0.055, 0.4)
        for step in range(8):
            pattern_index = ([0, 1, 2, 4, 3, 2, 5, 4] if journey else [0, 2, 1, 3, 4, 2, 5, 1])[step]
            note = patterns[chord_index][pattern_index]
            gain = (0.08 if step % 2 == 0 else 0.042) * (0.8 + min(1, bar / 8) * 0.2)
            add(melody, instruments.pluck(note, 1.6), start + step * 0.25, gain, math.sin(step * 1.4 + bar * 0.4) * 0.45)
        for offset, octave, gain in [(0, 0, 0.24), (0.75, 0, 0.13), (1.375, 12, 0.1)]:
            add(rhythm, instruments.bass(roots[chord_index] + octave), start + offset, gain)
    for beat_index in range(64):
        start = beat_index * BEAT
        add(rhythm, kick, start, 0.42 if journey else 0.48)
        add(rhythm, instruments.hat(0.07), start + 0.25, 0.045, 0.3)
        if beat_index % 4 in (1, 3):
            add(rhythm, instruments.hat(0.1), start, 0.065, -0.1)
        if start > 8:
            add(rhythm, instruments.hat(0.04), start + 0.375, 0.022, -0.35)
    sync = []
    for index, event in enumerate(cues["cues"]):
        position = event["audioTime"]
        sync.append({**event, "audioSample": round(position * RATE)})
        if position >= JOIN:
            continue
        pan = math.sin(index * 0.8) * 0.35
        kind = event["kind"]
        if kind == "sweep":
            add(effects, instruments.sweep(0.3), position - 0.2, 0.045, pan)
        elif kind in ("click", "tick", "letter"):
            add(effects, click, position, 0.05 if kind == "click" else 0.025, pan)
        elif kind in ("tone", "logo", "hit"):
            add(effects, instruments.pluck([74, 78, 81, 86][index % 4], 1.1), position, 0.06, pan)
            if kind == "hit":
                add(effects, kick, position, 0.14)
    harmony += echo(harmony, 0.173, 0.16) + echo(harmony, 0.337, 0.09)
    melody += echo(melody, 0.375, 0.2) + echo(melody, 0.75, 0.09)
    times = np.arange(samples) / RATE
    harmony *= (0.82 + 0.18 * (1 - np.exp(-np.mod(times, BEAT) * 20)))[:, None]
    mix = np.tanh((harmony + melody + rhythm + effects) * 0.95)
    mix *= 0.83 / max(float(np.max(np.abs(mix))), 1e-9)
    mix *= np.clip(times / 0.12, 0, 1)[:, None]
    original = read_wav(ORIGINAL / "exports" / "bande-son-originale.wav")
    cross_start = round(31 * RATE)
    join = round(JOIN * RATE)
    old_cross = round(26 * RATE)
    old_join = round(OLD_JOIN * RATE)
    cross = np.linspace(0, 1, join - cross_start, endpoint=False)[:, None]
    cross = cross * cross * (3 - 2 * cross)
    mix[cross_start:join] = mix[cross_start:join] * (1 - cross) + original[old_cross:old_join] * cross
    mix[join:] = original[old_join:]
    if not np.array_equal(mix[join:], original[old_join:]):
        raise ValueError("La fin sonore n’a pas été conservée")
    write_wav(OUTPUT / "bande-son-originale.wav", mix)
    manifest = {"version": ROOT.name, "duration": DURATION, "bpm": 120, "sampleRate": RATE, "channels": 2, "originalComposition": True, "externalSamples": False, "foreignReferenceAudioUsed": False, "preservedV3Tail": {"oldStart": OLD_JOIN, "newStart": JOIN, "sampleIdenticalBeforeAac": True, "crossfadeBeforeTail": [31, 31.5]}, "synchronizedEvents": len(sync), "peakDbfs": float(20 * np.log10(np.max(np.abs(mix)))), "rmsDbfs": float(20 * np.log10(np.sqrt(np.mean(mix * mix))))}
    (OUTPUT / "audio-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (OUTPUT / "sync-events.json").write_text(json.dumps({"sampleRate": RATE, "fps": 60, "samplesPerFrame": 800, "events": sync}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest))


if __name__ == "__main__":
    compose()
